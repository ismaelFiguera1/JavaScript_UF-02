import { Pelicula } from "./Pelicula.js";

const peli = new Pelicula(
  "1ghOP6987",
  "Colmillo blanco",
  "jose",
  1998,
  ["Spain", "France"],
  [
    "Game-Show",
    "History",
    "Romance",
    "Western",
  ],
  4.6
);

console.log(peli);
