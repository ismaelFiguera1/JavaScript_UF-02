export class Pelicula {
  constructor(id, titol, director, any, pais, generes, qualificacio) {
    this.ValidacioID(id);
  }

  ValidacioID(id) {
    let a;
  }
}
